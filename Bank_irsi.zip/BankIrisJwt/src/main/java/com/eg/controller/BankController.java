package com.eg.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank.model.BankAccount;
import com.example.bank.service.BankService;




@RestController 
@RequestMapping(name="/bank")
public class BankController 
{

	
	
	@Autowired
	BankService bService;
	
	@GetMapping("/")
	String met(){
		return "Hello World";
	}

	
	@PostMapping("/create")
	int createAccount(@Valid @RequestBody BankAccount bAccount){
		System.out.println("Bank Account Details:"+bAccount);
		
		return bService.createAccount(bAccount).getBid();
	}
	
	
	@GetMapping("/id")
	BankAccount retrieve(@RequestParam("bid") int bid){

		Optional<BankAccount> bAccount = bService.fetchAccount(bid);
		return bAccount.get();
	}
	
	
	//delete a Bank account
	@DeleteMapping("/id/delete")
	ResponseEntity<Object> delete(@RequestParam("id") int id){
		//retrieve bank account from db
		 bService.deleteAccount(id);
		  return new ResponseEntity<>("Deleted", HttpStatus.OK);
		
	}
	
	//update Bank Account
	@PutMapping("/id/update")
	ResponseEntity<Object> update(@RequestParam("bid") int bid,@RequestParam("name") String name){
		//retrieve bank account from db
 bService.updateAccount(bid,name);
		  return new ResponseEntity<>("Updated", HttpStatus.OK);
	}
	
}
